<?php
/**
 *
 *
 * @file
 * @ingroup Extensions
 */

$messages = array();

$messages['en'] = array(
        'contact'   => 'Contact us',
	'contact-desc'           => 'Adds a Bootstrap Styled contact form to BootStrapSkin',
);
