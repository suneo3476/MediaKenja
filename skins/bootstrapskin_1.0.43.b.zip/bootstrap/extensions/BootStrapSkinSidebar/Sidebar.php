    <div class="container-fluid hidden-xs hidden-sm">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#mwbs-navbar">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <div id="gn-menu" class="pull-left" style="margin-top:20px;position:fixed;">
                <div class="gn-menu-main">
                    <a class="gn-icon gn-icon-menu"><span>Guides</span></a>
                    <div class="gn-menu-wrapper">
                        <div class="gn-scroller">
                            <ul id="nav" class="nav nav-list">
                               <li>
                                    <a href="http://www.mediawikibootstrapskin.co.uk/index.php?title=BootStrap_Alerts" class="parent">
                                        <i class="fa fa-exclamation parent-first"></i>Alerts
                                    </a>
                                </li>
                                <li>
                                    <a href="http://www.mediawikibootstrapskin.co.uk/index.php?title=BootStrap_Buttons" class="parent">
                                        <i class="fa fa-hand-o-down parent-first"></i>Buttons
                                    </a>
                                </li>
                                <li>
                                    <a href="http://www.mediawikibootstrapskin.co.uk/index.php?title=Carousel" class="parent">
                                        <i class="fa fa-picture-o parent-first"></i>Carousel
                                    </a>
                                </li>                                                    
                                <li>
                                    <a href="http://www.mediawikibootstrapskin.co.uk/index.php?title=BootStrap_Colour_Classes" class="parent">
                                        <i class="fa fa-tint parent-first"></i>Colour Classes
                                    </a>
                                </li>
                                <li>
                                    <a href="http://www.mediawikibootstrapskin.co.uk/index.php?title=Columns" class="parent">
                                        <i class="fa fa-columns parent-first"></i>Columns
                                    </a>
                                </li>
                                <li>
                                    <a href="http://www.mediawikibootstrapskin.co.uk/index.php?title=Drop_Down_Nav" class="parent">
                                        <i class="fa fa-angle-double-down parent-first"></i>Drop Down Nav
                                    </a>
                                </li>                                                               
                                <li>
                                    <a href="http://www.mediawikibootstrapskin.co.uk/index.php?title=Icons_Sets" class="parent">
                                        <i class="fa fa-ellipsis-h parent-first"></i>Icon Sets
                                    </a>
                                </li>
                                <li>
                                    <a href="http://www.mediawikibootstrapskin.co.uk/index.php?title=BootStrap_Image_Boxes" class="parent">
                                        <i class="fa fa-picture-o parent-first"></i>Image Boxes
                                    </a>
                                </li>
                                <li>
                                    <a href="http://www.mediawikibootstrapskin.co.uk/index.php?title=Horizontal_Info_Boxes" class="parent">
                                        <i class="fa fa-info parent-first"></i>Info Boxes
                                    </a>
                                </li>                                                              
                                <li>
                                    <a href="http://www.mediawikibootstrapskin.co.uk/index.php?title=BootStrap_JumboTron" class="parent">
                                        <i class="fa fa-square parent-first"></i>JumboTron
                                    </a>
                                </li>
                                <li>
                                    <a href="http://www.mediawikibootstrapskin.co.uk/index.php?title=BootStrap_Modals" class="parent">
                                        <i class="fa fa-list-alt parent-first"></i>Modals
                                    </a>
                                </li>
                                <li>
                                    <a href="http://www.mediawikibootstrapskin.co.uk/index.php?title=BootStrap_Nav_Bar" class="parent">
                                        <i class="fa fa-exchange parent-first"></i>Nav Bar
                                    </a>
                                </li>
                                <li>
                                    <a href="http://mediawikibootstrapskin.co.uk/index.php?title=Nav_Tabs" class="parent">
                                        <i class="fa fa-exchange parent-first"></i>Nav Tabs
                                    </a>
                                </li>
                                <li>
                                    <a href="http://www.mediawikibootstrapskin.co.uk/index.php?title=BootStrap_Pagination" class="parent">
                                        <i class="fa fa-ellipsis-h parent-first"></i>Pagination
                                    </a>
                                </li>
                                <li>
                                    <a href="http://www.mediawikibootstrapskin.co.uk/index.php?title=BootStrap_Panels" class="parent">
                                        <i class="fa fa-bars parent-first"></i>Panels
                                    </a>
                                </li>
                                <li>
                                    <a href="http://www.mediawikibootstrapskin.co.uk/index.php?title=BootStrap_Pill_Nav" class="parent">
                                        <i class="fa fa-exchange parent-first"></i>Pill Nav
                                    </a>
                                </li>
                                <li>
                                    <a href="http://www.mediawikibootstrapskin.co.uk/index.php?title=BootStrap_Pop_Overs" class="parent">
                                        <i class="fa fa-angle-double-up parent-first"></i>Pop Overs
                                    </a>
                                </li>
                                <li>
                                    <a href="http://www.mediawikibootstrapskin.co.uk/index.php?title=Dismissable_Portlets" class="parent">
                                        <i class="fa fa-angle-double-down parent-first"></i>Portlets
                                    </a>
                                </li>
                                <li>
                                    <a href="http://www.mediawikibootstrapskin.co.uk/index.php?title=Custom_Social_Buttons" class="parent">
                                        <i class="fa fa-facebook parent-first"></i>Social Buttons
                                    </a>
                                </li>
                                <li>
                                    <a href="http://www.mediawikibootstrapskin.co.uk/index.php?title=BootStrap_Tables" class="parent">
                                        <i class="fa fa-table parent-first"></i>Tables
                                    </a>
                                </li>
                                <li>
                                    <a href="http://mediawikibootstrapskin.co.uk/demo/index.php?title=Thumbnails" class="parent">
                                        <i class="fa fa-picture-o parent-first"></i>Thumbnails
                                    </a>
                                </li>
                                <li>
                                    <a href="http://www.mediawikibootstrapskin.co.uk/index.php?title=BootStrap_Tool_Tips" class="parent">
                                        <i class="fa fa-wrench parent-first"></i>Tool Tips
                                    </a>
                                </li>
                                <li>
                                    <a href="http://www.mediawikibootstrapskin.co.uk/index.php?title=Typography" class="parent">
                                        <i class="fa fa-angle-double-up parent-first"></i>Typography
                                    </a>
                                </li>
                                
                                <li>
                                    <a href="http://www.mediawikibootstrapskin.co.uk/index.php?title=BootStrap_Wells" class="parent">
                                        <i class="fa fa-square-o parent-first"></i>Wells
                                    </a>
                                </li>                                
                                <li>
                                    <a href="http://www.mediawikibootstrapskin.co.uk/index.php?title=Custom_Modifications" class="parent">
                                        <i class="fa fa-wrench parent-first"></i>Custom Mods
                                    </a>
                                </li>
                                <!--li>
                                    <a href="javascript:" class="parent">
                                        <i class="fa fa-pencil parent-first"></i>Submenu
                                        <i class="fa fa-plus parent-icon"></i>
                                    </a>
                                    <ul class="bs-docs-sidenav" style="display:none;">
                                        <li>
                                            <a href="javascript:" class="child">
                                                <i class="fa fa-angle-right child-first"></i>Colored
                                            </a>
                                        </li>
                                        <li>
                                            <a href="javascript:" class="child">
                                                <i class="fa fa-angle-right child-first"></i>White
                                            </a>
                                        </li>
                                    </ul>
                                </li-->
                            </ul>

                        </div><!-- /gn-scroller -->
                    </div>
                </div>
            </div>
        </div>
    </div><!-- /.container-fluid -->