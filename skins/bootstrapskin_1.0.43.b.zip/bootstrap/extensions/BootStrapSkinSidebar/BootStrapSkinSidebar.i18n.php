<?php
/**
 *
 *
 * @file
 * @ingroup Extensions
 */

$messages = array();

$messages['en'] = array(
        'contact'   => 'Contact us',
	'sidebar-desc'           => 'Adds a jQuery pop out menu to BootStrapSkin',
);
