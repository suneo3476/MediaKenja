<?php
/**
 * Internationalisation file for skin BootstrapSkin
 *
 * @file
 * @ingroup Skins
 */

$messages = array();

/** English
 * @author Lee Miller
 */
$messages['en'] = array(
	'skinname-bootstrapskin' => "bootstrapskin",
	'bootstrapskin-desc' => "Provides a modified Vector skin utilising Bootstrap",
);
